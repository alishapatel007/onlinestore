export const GetMessages = (elem) => 
{
    const Messages = [];

    if(elem.validity.valueMissing){
        Messages.push("Value Required")
    }
    if(elem.validity.typeMismatch){
        Messages.push(`Invalid ${elem.type}`)
    }

    return Messages;

}