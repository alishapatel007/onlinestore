import React, { Component } from 'react';
import {Link} from 'react-router-dom';

export class Thanks extends Component{
    render(){
        return <div className="col bg-dark text-white">
            <div className="navbar-brand">
                Shoppy
            </div>
            <div className="m-2 text-center">
                <h2>Thanks</h2>
                <p>Thanks for placing your order !!</p>
                <p>your order is #{ this.props.order ? this.props.order.id : 0}</p>
                <p>we will ship you product(s) asap.</p>

                <Link to="/shop" className="btn btn-primary">
                    Return to Store
                </Link>
            </div>

        </div>
    }
}
