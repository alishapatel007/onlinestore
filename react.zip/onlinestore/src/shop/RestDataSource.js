import Axios from 'axios';
import {RestUrl} from './Url';

export class RestDataSource
{
    constructor(err_handler){
        this.error_handler = err_handler || (() => {});
    }

    GetData = (dataType, params) =>
        this.sendRequest("get", RestUrl[dataType], params);

    StoreData = (dataType, data) => 
        this.sendRequest("post", RestUrl[dataType], {}, data);

    sendRequest = (method, url, params, data) => 
        Axios.request({method, url, params, data });
}