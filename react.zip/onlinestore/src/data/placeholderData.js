export const data = {
    categories : ["waterSports", "soccer", "chess"],
    products : [
        {id:1, name:"WaterSports ABC", category:"waterSports", description:"ABC type product", price:40},
        {id:2, name:"French Soccer", category:"soccer", description:"ABC type product", price:30},
        {id:3, name:"WaterSports1 ABC", category:"waterSports", description:"ABC type product", price:140},
        {id:4, name:"Indian Soccer", category:"soccer", description:"ABC type product", price:340},
        {id:5, name:"Chess A", category:"chess", description:"ABC type product", price:240},
    ]
}