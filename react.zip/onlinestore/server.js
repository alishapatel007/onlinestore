const express = require("express");
const jsonServer = require("json-server");
const chokidar = require("chokidar");
const cors = require("cors");

//Graphql setup
const fs = require("fs");
const {buildSchema} = require("graphql");
const {graphqlHTTP} = require("express-graphql");
const queryResolvers = require("./serverQueriesResolver");
const mutationResolver = require("./serverMutationsResolver");


const fileName = process.argv[2] || "./data.js";
const port = process.argv[3] || 3500;

let router = undefined;
let graph = undefined;

const app = express();

//Configure the server
const createServer = () => {
    delete require.cache[require.resolve(fileName)];
    setTimeout(()=> {
        router = jsonServer.router(fileName.endsWith(".js") ? 
        require(fileName)() : fileName);
        //Graphql 
        let schema = fs.readFileSync("./QueriesSchema.graphql", "utf-8") +
            fs.readFileSync("./serverMutationsSchema.graphql","utf-8");
        

        let resolvers = {...queryResolvers , ...mutationResolver};
        graph = graphqlHTTP({
            schema : buildSchema(schema),
            rootValue : resolvers,
            graphiql : true,
            context : {db : router.db}
        })
    }, 100);
}

createServer();

//Configure the middleware
app.use(cors());
app.use(jsonServer.bodyParser);
app.use("/api", (req,resp,next) => router(req,resp,next));
app.use("/graphql", (req,resp,next) => graph(req,resp,next));

// Wrapper around node.js
chokidar.watch(fileName).on("change", ()=> {
    console.log("reloading webservices data");
    createServer();
    console.log("reloading webservices data complete");
});

//listen to port
app.listen(port, ()=>{
    console.log('webservice running on port - '+ port);
})