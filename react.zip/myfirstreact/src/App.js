import React, { Component } from "react";
import './App.css';

//import child components to parent
import {TodoBanner} from './TodoBanner'
import {TodoRow} from './TodoRow'
import {TodoCreator} from './TodoCreator'
import {VisibilityControl} from './VisibilityControl';

//Add dynamic data to app

export default class App extends Component
{
  constructor(props){
    super(props);
    this.state = {
      username : "Alisha",
      todoItems : [
        { action : "Buy flower",done : false},
        { action : "Read react",done : true},
        { action : "Perpare app",done : false},
        { action : "Check amazon",done : true}
      ],
      showCompleted : true,
      //newItemText : " "
    }
  }

  updateNewTextValue = (event) => {

    this.setState({ newItemText : event.target.value});
  }

  createNewTodo = (task) => {
    if (!this.state.todoItems
      .find(item => item.action === task))
      {
        //spread period
        this.setState({
          todoItems : [...this.state.todoItems,
                       {action : task,
                      done : false}]},

      ()=> localStorage.setItem("todos",
            JSON.stringify(this.state)));
                     // newItemText: ""
      }
  }

  toggleTodo = (todo) => this.setState({
    todoItems : this.state.todoItems.map(
      item => item.action === todo.action ? 
      {...item, done : !item.done} : item
    )});

  todoTableRows = (doneValue) => this.state.todoItems
    .filter(item => item.done === doneValue)
    .map
        (item => 
          <TodoRow key={item.action}
          item={item} callback={this.toggleTodo}/>
          
          /* <tr key={item.action}>
            <td>
                {item.action}
            </td>
            <td>
              <input type="checkbox" checked= {item.done}
                onChange={() => this.toggleTodo(item)}/>
            </td>
          </tr> */
        );

    // Load the data - saved todos
    componentDidMount = () => {
      let data = localStorage.getItem("todos");
      this.setState(data != null ? JSON.parse(data) : 
        {
          username : "Alisha",
          todoItems : [
            { action : "Buy flower",done : false},
            { action : "Read react",done : true},
            { action : "Perpare app",done : false},
            { action : "Check amazon",done : true}],
          showCompleted : true
        });
    }

  render()
  {
    return(
    <div>
        
        <TodoBanner name={this.state.username} tasks={this.state.todoItems}/>
      <div className="container-fluid">
       
        <TodoCreator callback={this.createNewTodo}/>
        <table className="table table-striped table-bordered">
          <thead>
            <th>Todo Tasks</th>
            <th>Done</th>
          </thead>
          <tbody>
            {/* Show Incomplete tasks */}
            {this.todoTableRows(false)}
          </tbody>
        </table>
        <div className="bg-danger text-white text-center p-2">
          <VisibilityControl description="Completed Tasks" 
          isChecked = {this.state.showCompleted}
          callback = {(checked) => this.setState({showCompleted : checked})}/>
        </div>
          {
            this.state.showCompleted &&
            <table className="table table-striped table-bordered">
              <thead>
                <tr>
                  <td>Task Name</td>
                  <td>Status</td>
                </tr>
              </thead>
              <tbody>
                {/* Show Completed tasks */}
                {this.todoTableRows(true)}
              </tbody>
            </table>
          }
        
      </div>
    </div>
    )
  };
}

/* <h4 className="bg-primary text-white text-center p-2">
          {this.state.username}'s ToDo List
          ({this.state.todoItems.filter(t => !t.done).length})
        </h4> */

 /* <div className="m-1">
          <input 
              className="form-control" 
              value={this.state.newItemText}
              onChange={this.updateNewTextValue} />
          <button className="btn btn-danger m-1"
            onClick={this.createNewTodo}>Add Task</button>
        </div> */